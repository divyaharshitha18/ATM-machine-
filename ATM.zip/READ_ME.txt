Additional Header files used(other than <stdio.h>):

# include <stdlib.h>
# include <conio.h>
# include <time.h>
# include <string.h>



Steps to be followed to implement the code:

1.Replace the file path by your file path wherever commented in the code.

2.Create an admin folder, output folder.

3.Create a txt file with its name being cardnameofatmcard ,
  the name of your ATM card can be letters or numbers or both
  (for example if my cardname is 200030098 then the name of txt file created should be card200030098)

4.Enter your account number(9-digit number) in that file.

5.Now, create another txt file named accountnumber
  (for example, if my account number is 200030099 then the name of this txt file should be 200030099)

6.Enter the data into accountnumber.txt file as follows:
     First line : Account number(9-digit number)
     Second line: Mobile number(10-digit number)
     Third line : Pin number(4-digit number)
     Fourth line: Account balance

7.In the output folder create another folder with name as the mobile number(as entered in accountnumber.txt).

8.Create a txt file named atmbalance and enter the atmbalance you wish. 

9.Instead of creating all these folders and files you can directly access them from the zip file.




Why are these folders and txt files useful?

~>The admin folder contains logs.txt file(this txt file need not be manually created), this txt file has details of all 
transactions of all the users.

~>The output folder has 3 txt files(these txt files need not be manually created);
 a)otp.txt -> It contains all the OTP messages.
 b)withdrawal.txt -> It contains messages regarding withdrawal of money.
 c)deposit.txt -> It contains messages regarding cash deposit.
 This output folder is basically the mimic of messages which we get to our phone after every succesful action.

~>cardnameofatmcard.txt contains account number,which searches for accountnumber.txt.
 This is the mimic to inserting the card in the ATM machine.

~>accountnumber.txt contains all the details of the user, useful for performing the actions.

~>atmbalance.txt has the maximum amount which the user can withdraw using ATM,
 even if the user has account balance more than atmbalance the withdrawal will not be possible.




Where did we use additional header files?

stdlib.h : It was used for atoi(), srand(),exit(),rand()

conio.h : It was used for getch()

time.h : It was used for srand(time(null)) also for printing time in messages about every action.

string.h : It was used for concatenating, copying file paths and the account details of user stored in structure.
           i.e, for using strcat(),strcpy().










