# include <stdio.h>
# include <stdlib.h>
# include <conio.h>
# include <time.h>
# include <string.h>

struct data{
    char accno[11], phone[12], pin[6], balance[20];
};
struct data  user1;

// pin function
int password(int a)
{
    int pinlen = 4;          
    char pin[pinlen + 1];  
    char ch;                 
    int charposition = 0;
    while(1)
    {
        ch = getch();
         
         
        if(ch == 13)
        {
            break;  //13 is ascii value of enter key. When user hits enter key, the loop will break
        }
        else if(ch == 32 || ch == 9)
        {
            continue; //30 and 9 are for space and tab, we need to skip spaces and tabs in the pin
        }
        else if(ch == 8) //8 is ascii value of backspace
        {
            if(charposition>0){           
                charposition--;
                pin[charposition] = '\0';
                printf("\b \b");
            }
        }
        else
        {
            if(charposition<pinlen){
                pin[charposition] = ch;
                charposition++;
                printf("*");
            }
            else{
                printf(" \b");
            }
        }
    }
    pin[charposition] = '\0';


    if(atoi(pin) == a){
        return 1;
    }
    else{
        return atoi(pin);
    }   
}

// random number generator
int random(){
    srand(time(NULL));
    int n = (rand() % (9999-1000 + 1) + 1000);
    return n;
}
// pin change function
int pinchange(int *a, int s1, int s2){
    char c1 = s1;
    char c2 = s2;
    char path[100];
    char phone[11];
    int otp;
    while(1){
        printf("AN OTP HAS BEEN SENT ON YOUR PHONE NUMBER XXXXXXXX%c%c\n", user1.phone[8], user1.phone[9]);
        otp = random();
        strcpy(phone, user1.phone);
        phone[10] = '\0';
        strcpy(path, "C:/CS101project/output/");    // change C:/CS101project/ to your directory *********
        strcat(path, phone);
        strcat(path, "/otp.txt");
        time_t tm;
        time(&tm);
        FILE*change;
        change = fopen(path, "a");
        fprintf(change, "\n\n%s\nYour one time password for changing your ATM pin for account number - XXXXXXX%c%c is %d", ctime(&tm), c1, c2, otp);
        fclose(change);


        printf("PRESS 1 TO ENTER OTP\nPRESS 2 TO RESEND OTP\nPRESS ANY OTHER KEY TO EXIT\n");
        int m;
        scanf("%d", &m);
        if(m == 1){
            printf("\nENTER THE OTP\n");
            int c;
            scanf("%d", &c);
            if(c == otp){
                while(1){
                    printf("\nENTER A NEW PIN\n");
                    int temp;
                    temp = password(100);
                    printf("\nCONFIRM YOUR NEW PIN\n");
                    int final;
                    final = password(100);
                    if(final == *a){
                        printf("\nYOU CANNOT ENTER YOUR OLD PIN\nPRESS 1 TO TRY AGAIN, PRESS ANY OTHER KEY TO EXIT\n");
                        int n;
                        scanf("%d", &n);
                        if(n == 1){
                            continue;
                        }
                        else{
                            break;
                        }
                    }
                    else if(temp == final){
                        *a = final;
                        printf("\nPIN CHANGE SUCCESSFUL\n");
                        printf("\n************************    HAVE A GREAT DAY    ************************\n");
                        break;
                    }
                    
                    else{
                        printf("\nPINS DIDN'T MATCHED\nPRESS 1 TO TRY AGAIN, PRESS ANY OTHER KEY TO EXIT\n");
                        int n;
                        scanf("%d", &n);
                        if(n == 1){
                            continue;
                        }
                        else{
                            break;
                        }
                    }
                }
            }
            else{
                printf("THE OTP ENTERED IS INCORRECT\nPRESS 1 TO RESEND THE OTP\nPRESS ANY OTHER KEY TO EXIT\n");
                int n;
                scanf("%d", &n);
                if(n == 1){
                    continue;
                }
                else{
                    break;
                }
            }
            break;
        }
        else if(m == 2){
            continue;
        }
        else{
            break;
        }
    }
    return 0;
}

// admin function
int admin(int *balance){
    printf("************************  ADMIN LOGIN DETECTED  ************************\n");
    printf("ENTER YOUR PIN, MAX 3 CHANCES ARE ALLOWED TO ENTER PIN CORRECTLY\n");
    int i = 0;
    while(i<3){
        if(password(2552) == 1){
            printf("\nADMIN LOGIN SUCCESSFUL\n");
            printf("PRESS 1 TO VIEW LOGS\nPRESS 2 TO CHECK OR MODIFY ATM BALANCE\nPRESS ANY OTHER KEY TO EXIT\n");
            int choice;
            scanf("%d",&choice);
            if(choice == 1){
                FILE*log;
                log = fopen("C:/CS101project/admin/logs.txt","r");  // change C:/CS101project/ to your directory *********
                char ch;
                while((ch = fgetc(log)) != EOF){
                    printf("%c", ch);
                }
                fclose(log);
                break;
            }
            else if(choice == 2){
                printf("CURRENT ATM BALANCE IS %d \n", *balance);
                printf("PRESS 1 TO DEPOSIT MONEY\nPRESS 2 TO WITHDRAW MONEY\nPRESS ANY OTHER KEY TO EXIT\n");
                int o;
                scanf("%d", &o);
                switch(o)
                {
                    case 1:
                    {
                        int amt;
                        printf("ENTER THE AMOUNT TO BE DEPOSITED\n");
                        scanf("%d", &amt);
                        *balance = *balance + amt;
                        time_t tm;
                        time(&tm);
                        printf("Amount was deposited successfully, current atm balance %d\n", *balance);
                        FILE*log;
                        log = fopen("C:/CS101project/admin/logs.txt","a");     // change C:/CS101project/ to your directory *********
                        fprintf(log, "\n\n%s\nINR %d DEPOSITED to ATM\n", ctime(&tm), amt);
                        fclose(log);
                        break;
                    }
                    case 2:
                    {
                        int amt;
                        printf("ENTER THE AMOUNT TO BE WITHDRAWN\n");
                        scanf("%d", &amt);
                        if(amt > *balance){
                            printf("INSUFFICIENT BALANCE\n");
                            break;
                        }
                        else{
                            *balance = *balance - amt;
                            time_t tm;
                            time(&tm);
                            printf("Withdrawl successful, current atm balance %d \n", *balance);
                            FILE*log;
                            log = fopen("C:/CS101project/admin/logs.txt","a");  // change C:/CS101project/ to your directory *********
                            fprintf(log, "\n\n%s\nINR %d WITHDRAW from ATM\n", ctime(&tm), amt);
                            fclose(log);
                            break;
                        }
                    }
                    default:
                        break;
                }
            }
            else{
                break;
            }
            break;
        }
        else{
            if(i<2){
                printf("\nINCORRECT PIN, TRY AGAIN\n");
            }
            else{
                printf("\nMAXIMUM CHANCES REACHED, PLEASE REINSERT YOUR CARD AND TRY AGAIN\n");
            }
        }
        i++;
    }
    return 0;
}

// withdrawl
int withdrawl(int *balance, int *atm, int s1, int s2){      /// Declaring function for withdrawl
    int amt;
    char c1 = s1;
    char c2 = s2;
    char path[100];
    char phone[11];
    
    while(1){
        printf("\nENTER THE AMOUNT YOU WISH TO WITHDRAW\n");
        scanf("%d", &amt);
        if(amt <= *balance){
            if(amt > *atm){
                printf("INSUFFICIENT BALANCE AVAILABLE IN THE ATM, PLEASE CONTACT THE BANK HELPLINE\n");
                break;
            }
            *balance = *balance - amt;
            *atm = *atm - amt;
            time_t tm;
            time(&tm);
            
            printf("Withdrawal successful, available balance is INR %d\n", *balance);
            printf("\n************************    HAVE A GREAT DAY    ************************\n");
            strcpy(phone, user1.phone);
            phone[10] = '\0';
            strcpy(path, "C:/CS101project/output/");   // change C:/CS101project/ to your directory *********
            strcat(path, phone);
            strcat(path, "/withdrawal.txt");
            FILE*msg;
            msg = fopen(path, "a");
            fprintf(msg,"\n\n%s\nINR %d debited from your account XXXXXXX%c%c, available balance - INR %d\n", ctime(&tm), amt, c1, c2, *balance);
            fclose(msg);

            FILE*log;
            log = fopen("C:/CS101project/admin/logs.txt","a");    // change C:/CS101project/ to your directory *********
            fprintf(log, "\n\n%s\nINR %d WITHDRAWN from %s", ctime(&tm), amt, user1.accno);
            break;
        }
        else{
            printf("INSUFFICIENT BALANCE IN YOUR ACCOUNT\nPRESS 1 TO RETRY\nPRESS ANY OTHER KEY TO EXIT\n");
            int m;
            if(m == 1){
                continue;
            }
            else{
                break;
            }
        }
    }
    return 0;
}

// Deposit
int deposit(int *balance, int s1, int s2){  
    int amt;
    char c1 = s1;
    char c2 = s2;
    char path[100];
    char phone[11];
    
    while(1){
        printf("ENTER THE AMOUNT YOU WISH TO DEPOSIT, MAXIMUM LIMIT INR 50,000\n");
        scanf("%d", &amt);
        if(amt <= 50000){
            *balance = *balance + amt;
            time_t tm;
            time(&tm);
            
            printf("Deposit successful, available balance - INR %d\n", *balance);
            printf("\n************************    HAVE A GREAT DAY    ************************\n");
            strcpy(phone, user1.phone);
            phone[10] = '\0';
            
            strcpy(path, "C:/CS101project/output/");   // change C:/CS101project/ to your directory *********
            strcat(path, phone);
            strcat(path, "/deposit.txt");
            
            FILE*msg;
            msg = fopen(path, "a");
            fprintf(msg, "\n\n%s\nINR %d credited to your account XXXXXXX%c%c, available balance - INR %d\n", ctime(&tm), amt, c1, c2, *balance);
            fclose(msg);

            FILE*log;
            log = fopen("C:/CS101project/admin/logs.txt","a");   // change C:/CS101project/ to your directory *********
            fprintf(log, "\n\n%s\nINR %d DEPOSITED to %s", ctime(&tm), amt, user1.accno);
            break;
        }
        else{
            printf("THE ENTERED AMOUNT IS GREATER THEN MAXIMUM LIMIT\nPRESS 1 TRY AGAIN, PRESS ANY OTHER KEY TO EXIT\n");
            int m;
            scanf("%d", &m);
            if(m == 1){
                continue;
            }
            else{
                break;
            }
        }
    }
    return 0;
}

// money transfer
int transfer(int *balance, int s1, int s2){
    char c1 = s1;
    char c2 = s2;
    char receiver[11];
    char path[100];
    char phone[11];
    char path2[100];
    char phone2[11];
    char ac2[10];
    struct data user2;
    int amt;
    int a,account2;
    
    while(1){               
        printf("ENTER THE BENEFICIARY'S ACCOUNT NUMBER\n");
        scanf("%d", &a);
        printf("PLEASE RE-ENTER THE BENEFICIARY'S ACCOUNT NUMBER\n");
        scanf("%d",&account2);
        if(a!=account2){
            printf("The two account numbers do not match . Please try again \n");
            continue;
        }
        sprintf(receiver, "%d", account2);
        char user2path[100];
        strcpy(user2path, "C:/CS101project/Database/");    // change C:/CS101project/ to your directory *********
        strcat(user2path, receiver);
        strcat(user2path, ".txt");
        
            
        FILE*receiver;
        receiver = fopen(user2path, "r");
        if(receiver == NULL){
                    
            printf("ACCOUNT NOT FOUND\nPRESS 1 TO RETRY, PRESS ANY OTHER KEY TO EXIT\n");
            fclose(receiver);
            int m;
            scanf("%d", &m);
            if(m == 1){
                continue;
            }
            else{
                break;
            }
        }
        else{
            while(1){
                printf("ENTER THE AMOUNT TO BE TRANSFERRED \n");
                    
                scanf("%d", &amt);
                printf("\nINR %d is the amount entered\nPress 1 to continue, press any other key to re-enter the amount\n", amt);
                int d;
                scanf("%d", &d);
                if(d!=1){continue;}
                else if(d == 1){
                    if(amt<*balance){
                        fgets(user2.accno, 11, receiver);
                        fgets(user2.phone, 12, receiver);
                        fgets(user2.pin, 6, receiver);
                        fgets(user2.balance, 20, receiver);
                        fclose(receiver);
                        int balance2 = atoi(user2.balance);
                
                        balance2 = balance2 + amt;
                
                        *balance = *balance - amt;
                        sprintf(user2.balance, "%d", balance2);
                        time_t tm = time(NULL);
                        
                
                        FILE*overwrite;
                        overwrite = fopen(user2path, "w+");
                        fprintf(overwrite, "%s%s%s%s", user2.accno, user2.phone, user2.pin, user2.balance);
                        fclose(overwrite);
                        printf("Transaction successful, available balance INR %d\n", *balance);
                        printf("\n************************    HAVE A GREAT DAY    ************************\n");
                        strcpy(phone, user1.phone);
                        phone[10] = '\0';
                        strcpy(path, "C:/CS101project/output/");    // change C:/CS101project/ to your directory *********
                        strcat(path, phone);
                        strcat(path, "/transfer.txt");
                        FILE*msg;
                        msg = fopen(path, "a");  
                        fprintf(msg, "\n\n%s\nINR %d transferred to account XXXXXXX%c%c from your account XXXXXXX%c%c, available balance INR %d", ctime(&tm), amt, user2.accno[7], user2.accno[8], c1, c2, *balance);
                        fclose(msg);
                        

                        strcpy(phone2, user2.phone);
                        phone2[10] = '\0';
                        strcpy(path2, "C:/CS101project/output/");  // change C:/CS101project/ to your directory *********
                        strcat(path2, phone2);
                        strcat(path2, "/receive.txt");            
                        FILE*msg2;
                        msg2 = fopen(path2, "a");
                        fprintf(msg2, "\n\n%s\nINR %d received from account XXXXXXX%c%c in your account XXXXXXX%c%c, available balance - INR %d", ctime(&tm), amt, user1.accno[7], user1.accno[8], user2.accno[7], user2.accno[8], balance2);
                        fclose(msg2);

                         
                        strcpy(ac2, user2.accno);
                        ac2[9] = '\0'; 
                        FILE*log;
                        log = fopen("C:/CS101project/admin/logs.txt","a"); // change C:/CS101project/ to your directory *********
                        fprintf(log, "\n\n%s\nINR %d TRANSFERRED to %s from %s", ctime(&tm), amt, ac2, user1.accno);
                        fclose(log);
                        break;
                    }    
                    else{
                        printf("INSUFFICIENT BALANCE\nPRESS 1 TO RETRY\nPRESS ANY OTHER KEY TO EXIT\n");
                        int n;
                        scanf("%d", &n);
                        if(n == 1){
                            continue;
                        }
                        else{
                            break;
                        }
                    }    
                }
                break;
            }    
        }
        break;
    }
    return 0;
}




// main function
int main(){
    char atmbalance[20];
    FILE*ptr;
    ptr = fopen("C:/CS101project/admin/atmbalance.txt","r");    // change C:/CS101project/ to your directory *********
    fgets(atmbalance, 20, ptr);
    fclose(ptr);
    int atm = atoi(atmbalance);
    printf("************************ WELCOME TO ATM SERVICE ************************\n");
    printf("PLEASE INSERT YOUR ATM CARD\n");
    char card[15], carddata[11];
    char cardpath[] = "C:/CS101project/Card/";   // change C:/CS101project/ to your directory *********
    scanf("%[^\n]", card);
    strcat(cardpath, card);
    strcat(cardpath, ".txt");

    FILE*opn;
    opn = fopen(cardpath, "r");
    if(opn == NULL){
        printf("CARD WAS NOT RECOGNISED\n");
        exit(1);
    }
    fscanf(opn, "%[^\n]", carddata);
    fclose(opn);

    char accpath[] = "C:/CS101project/Database/";     // change C:/CS101project/ to your directory *********
    strcat(accpath, carddata);
    strcat(accpath, ".txt");
    FILE*account;
    account = fopen(accpath, "r");
    if(account == NULL){
        printf("ACCOUNT NOT FOUND\n");
        exit(1);
    }
    fgets(user1.accno, 11, account);
    fgets(user1.phone, 12, account);
    fgets(user1.pin, 6, account);
    fgets(user1.balance, 20, account);
    fclose(account);

    if(atoi(user1.accno) == 100010011){        // account number for admin
        admin(&atm);
        sprintf(atmbalance, "%d", atm);    
        
        FILE*overwrite;                       
        overwrite = fopen("C:/CS101project/admin/atmbalance.txt", "w+");   // change C:/CS101project/ to your directory *********
        fprintf(overwrite, "%s", atmbalance);
        fclose(overwrite);
    }
    else{
        printf("PRESS 1 TO ENTER YOUR 4 DIGIT PIN\n(MAXIMUM 3 CHANCES ALLOWED FOR SUCCESSFULLY ENTERING THE PIN)\nPRESS 2 FOR PIN CHANGE\nPRESS ANY OTHER KEY TO EXIT\n");
        int a;
        scanf("%d", &a);
        if(a == 1){
            printf("ENTER YOUR PIN\n");
            int i=0;
            while(i < 3){
                if(password(atoi(user1.pin)) == 1){
                    while(1){
                        printf("\n************************************************************************\n");
                        printf("\n1.CASH WITHDRAWL\n2.CASH DEPOSIT\n3.BALANCE CHECK\n4.PIN CHANGE\n5.MONEY TRANSFER\n");
                        printf("SELECT ANY ONE OF THE ABOVE, PRESS ANY OTHER KEY TO EXIT\n");
                        int choice;
                        scanf("%d", &choice);
                        printf("************************************************************************\n");
                        switch(choice)
                        {
                            case 1:
                            {
                                int balance = atoi(user1.balance);
                                withdrawl(&balance, &atm, user1.accno[7], user1.accno[8]);
                                sprintf(user1.balance, "%d", balance);
                                sprintf(atmbalance, "%d", atm);
                                break;
                            }
                            case 2:
                            {
                                int balance = atoi(user1.balance);
                                deposit(&balance, user1.accno[7], user1.accno[8]);
                                sprintf(user1.balance, "%d", balance);    
                                break;
                            }
                            case 3:
                            {
                                printf("Current balance in your account is INR %s", user1.balance);
                                printf("\n************************    HAVE A GREAT DAY    ************************\n");
                                break;
                            }
                            case 4:
                            {
                                int pass = atoi(user1.pin);
                                pinchange(&pass, user1.accno[7], user1.accno[8]);
                                sprintf(user1.pin, "%d", pass);                            
                                break;
                            }
                            case 5:
                            {
                                int balance = atoi(user1.balance);
                                transfer(&balance, user1.accno[7], user1.accno[8]);
                                sprintf(user1.balance, "%d", balance);
                                break;
                            }
                            
                            default:
                            {
                                printf("\n************************  PROCESS ENDED BY USER ************************\n");
                                exit(1);
                            }
                            
                            
                        }
                        user1.pin[4] = '\n';
                        FILE*overwrite;
                        overwrite = fopen(accpath, "w+");
                        fprintf(overwrite ,"%s%s%s%s", user1.accno, user1.phone, user1.pin, user1.balance);
                        fclose(overwrite);

                        FILE*fptr;  // atm balance overwrite
                        fptr = fopen("C:/CS101project/admin/atmbalance.txt","w+");   // change C:/CS101project/ to your directory *********
                        fprintf(fptr, "%s", atmbalance);
                        fclose(fptr);
        
                        printf("PRESS 1 IF YOU WISH TO PERFORM FURTHER TRANSACTION\nPRESS ANY OTHER KEY TO EXIT\n");
                        int o;
                        scanf("%d", &o);
                        if(o == 1){
                            continue;
                        }
                        else{
                            break;
                        }
                        break;
                    }
                    break;    
                }
                else{
                    if(i<2){
                        printf("\nINCORRECT PIN, TRY AGAIN\n");
                    }
                    else{
                        printf("\nMAXIMUN CHANCES REACHED, please re-insert your card and try again\n");
                    }
                }
                i++;
            }
        }
        else if(a == 2){
            printf("************************************************************************\n");
            int pass = atoi(user1.pin);
            pinchange(&pass, user1.accno[7], user1.accno[8]);
            sprintf(user1.pin, "%d", pass);
        }
        else{
            printf("\n************************  PROCESS ENDED BY USER ************************\n");
            exit(1);
        }
        

    }
                                       
    getch();   
    return 0;
}
